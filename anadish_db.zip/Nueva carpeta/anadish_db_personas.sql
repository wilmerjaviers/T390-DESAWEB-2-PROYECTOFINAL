-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: anadish_db
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `personas`
--

DROP TABLE IF EXISTS `personas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) NOT NULL,
  `cedula` varchar(20) NOT NULL,
  `genero` enum('Masculino','Femenino') NOT NULL,
  `estado_civil` enum('Soltero/a','Casado/a','Divorciado/a','Viudo/a') DEFAULT NULL,
  `fecha_nacimiento` date NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `departamento` varchar(50) NOT NULL,
  `municipio` varchar(50) NOT NULL,
  `direccion_completa` text NOT NULL,
  `nivel_prioridad` enum('high','medium','low') NOT NULL DEFAULT 'medium',
  `estado` enum('activo','inactivo') DEFAULT 'activo',
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario_registro` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cedula` (`cedula`),
  KEY `usuario_registro` (`usuario_registro`),
  KEY `idx_personas_cedula` (`cedula`),
  KEY `idx_personas_prioridad` (`nivel_prioridad`),
  CONSTRAINT `personas_ibfk_1` FOREIGN KEY (`usuario_registro`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personas`
--

LOCK TABLES `personas` WRITE;
/*!40000 ALTER TABLE `personas` DISABLE KEYS */;
INSERT INTO `personas` VALUES (1,'Yessenia Lopez','1234567890','Femenino','Soltero/a','1985-03-15','+504 9876-5432',NULL,'Francisco Morazán','Tegucigalpa','Col. Kennedy, Bloque M, Casa 15','high','activo','2025-06-09 04:01:12',1),(2,'Yossif Gomez','0987654321','Masculino','Casado/a','1978-11-20','+504 8765-4321',NULL,'Francisco Morazán','Tegucigalpa','Barrio La Granja, Calle Principal','medium','activo','2025-06-09 04:01:12',1),(3,'Manuel Monterrey','1122334455','Masculino','Viudo/a','1965-07-08','+504 7654-3210',NULL,'Francisco Morazán','Comayagüela','Col. Torocagua, Casa 45','high','activo','2025-06-09 04:01:12',1),(4,'Henry Anderson','5566778899','Masculino','Divorciado/a','1990-12-03','+504 6543-2109',NULL,'Francisco Morazán','Tegucigalpa','Res. Las Colinas, Casa 78','low','activo','2025-06-09 04:01:12',1),(5,'Wilmer J. Sanchez','0801198405841','Masculino','Soltero/a','1984-06-21','+50433382469','sanchezshs@gmail.com','Francisco Morazán','Tegucigalpa','Villa Vieja\nTegucigalpa','low','activo','2025-06-09 05:32:20',1),(7,'Wilmer Javier Sanchez Sanabria','0801198405481','Masculino','Divorciado/a','1984-06-21','+50433382469','sanchezshs@gmail.com','Francisco Morazán','Tegucigalpa','Villa Vieja\nTegucigalpa','medium','activo','2025-06-11 04:08:11',1),(8,'Olga Vasquez','0823198600090','Femenino','Viudo/a','1986-10-07','33370026','olga@prueba.com','Francisco Morazán','Tegucigalpa','cerro grande.','high','activo','2025-06-11 04:28:13',1),(9,'Yisel Moncada','0819199005488','Femenino','Soltero/a','1990-01-21','33333333','yisel.moncada@gmail.com','Francisco Morazán','Tegucigalpa','hato del miedo.','medium','activo','2025-06-12 02:26:08',1),(10,'Hector Oliva','0813200200190','Masculino','Viudo/a','2002-05-04','33333333','hector.oliva@gmail.com','Francisco Morazán','Tegucigalpa','por ahi.','medium','activo','2025-06-14 02:24:43',1),(11,'Noel Rivas','1324194912345','Masculino','Soltero/a','1949-01-01','+504533501475','noelrivas@yahoo.com','Francisco Morazán','Valle de Ángeles','en valle.','high','activo','2025-06-14 02:35:01',1),(12,'Ivan Zamorano','1516199000004','Masculino','Casado/a','1990-06-17','+50433382469','ivan.zamorano@gmail.com','Francisco Morazán','Valle de Ángeles','valle de angeles.','medium','activo','2025-06-17 15:12:11',1);
/*!40000 ALTER TABLE `personas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-17 11:04:34
