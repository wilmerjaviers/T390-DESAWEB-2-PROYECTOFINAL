-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: anadish_db
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `solicitudes`
--

DROP TABLE IF EXISTS `solicitudes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitudes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `persona_id` int NOT NULL,
  `tipo_ayuda_id` int NOT NULL,
  `monto_estimado` decimal(10,2) NOT NULL,
  `urgencia` enum('Alta','Media','Baja') NOT NULL DEFAULT 'Media',
  `descripcion` text NOT NULL,
  `fecha_esperada` date DEFAULT NULL,
  `estado` enum('Pendiente','En revisión','Aprobado','Rechazado','Procesando') DEFAULT 'Pendiente',
  `fecha_solicitud` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `usuario_solicita` int DEFAULT NULL,
  `usuario_aprueba` int DEFAULT NULL,
  `observaciones` text,
  PRIMARY KEY (`id`),
  KEY `persona_id` (`persona_id`),
  KEY `tipo_ayuda_id` (`tipo_ayuda_id`),
  KEY `usuario_solicita` (`usuario_solicita`),
  KEY `usuario_aprueba` (`usuario_aprueba`),
  KEY `idx_solicitudes_estado` (`estado`),
  KEY `idx_solicitudes_fecha` (`fecha_solicitud`),
  CONSTRAINT `solicitudes_ibfk_1` FOREIGN KEY (`persona_id`) REFERENCES `personas` (`id`),
  CONSTRAINT `solicitudes_ibfk_2` FOREIGN KEY (`tipo_ayuda_id`) REFERENCES `tipos_ayuda` (`id`),
  CONSTRAINT `solicitudes_ibfk_3` FOREIGN KEY (`usuario_solicita`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `solicitudes_ibfk_4` FOREIGN KEY (`usuario_aprueba`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes`
--

LOCK TABLES `solicitudes` WRITE;
/*!40000 ALTER TABLE `solicitudes` DISABLE KEYS */;
INSERT INTO `solicitudes` VALUES (1,1,1,3500.00,'Alta','Necesita medicamentos para diabetes urgentemente','2025-06-15','Aprobado','2025-06-09 04:01:12','2025-06-10 02:45:40',1,NULL,'Ayuda otorgada'),(2,2,2,2200.00,'Media','Familia necesita alimentos básicos para el mes','2025-06-20','Procesando','2025-06-09 04:01:12','2025-06-09 04:01:12',1,NULL,NULL),(3,3,3,18500.00,'Alta','Reparación urgente del techo por daños de lluvia','2025-06-10','Aprobado','2025-06-09 04:01:12','2025-06-09 04:01:12',1,NULL,NULL),(4,4,4,1200.00,'Baja','Materiales escolares para sus hijos','2025-07-01','Rechazado','2025-06-09 04:01:12','2025-06-10 02:44:46',1,NULL,'porque si'),(5,5,2,4000.00,'Alta','Ayuda para Wilmer Sanchez.','2025-06-10','Aprobado','2025-06-10 02:26:19','2025-06-17 14:51:27',1,NULL,'Ayuda otorgada'),(6,8,4,6000.00,'Alta','le urge.','2025-06-21','Aprobado','2025-06-11 04:30:07','2025-06-17 14:51:48',1,NULL,'Ayuda otorgada'),(7,8,5,9000.00,'Baja','tambien lo necesita. ','2025-07-30','Pendiente','2025-06-11 04:38:47','2025-06-11 04:38:47',1,NULL,NULL),(8,9,3,7000.00,'Media','no tiene dinero.','2025-06-21','Aprobado','2025-06-12 02:27:00','2025-06-12 02:28:09',1,NULL,'Ayuda otorgada'),(9,11,4,5000.00,'Media','ejemplo.','2025-06-25','Aprobado','2025-06-14 02:38:45','2025-06-17 14:52:30',1,NULL,'Ayuda otorgada'),(10,10,3,20000.00,'Alta','lo necesita','2025-06-18','Pendiente','2025-06-17 15:09:13','2025-06-17 15:09:13',1,NULL,NULL);
/*!40000 ALTER TABLE `solicitudes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-17 11:04:35
